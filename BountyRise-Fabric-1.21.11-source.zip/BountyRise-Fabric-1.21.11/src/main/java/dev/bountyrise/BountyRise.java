package dev.bountyrise;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class BountyRise implements ModInitializer {
    // MVP prototype: values reset when the server restarts.
    private static final Map<UUID, Integer> KILLS = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> DIAMOND_BOUNTY = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> NETHERITE_BOUNTY = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity instanceof ServerPlayerEntity victim)) return;

            Entity attackerEntity = damageSource.getAttacker();
            if (!(attackerEntity instanceof ServerPlayerEntity killer)) return;
            if (killer.getUuid().equals(victim.getUuid())) return;

            UUID killerId = killer.getUuid();
            UUID victimId = victim.getUuid();

            // Pay the victim's accumulated bounty to the killer.
            int diamondsOwed = DIAMOND_BOUNTY.getOrDefault(victimId, 0);
            int netheriteOwed = NETHERITE_BOUNTY.getOrDefault(victimId, 0);
            if (diamondsOwed > 0) {
                int left = diamondsOwed;
                while (left > 0) {
                    int stack = Math.min(left, 64);
                    killer.giveItemStack(new net.minecraft.item.ItemStack(Items.DIAMOND, stack));
                    left -= stack;
                }
            }
            if (netheriteOwed > 0) {
                killer.giveItemStack(new net.minecraft.item.ItemStack(Items.NETHERITE_INGOT, netheriteOwed));
            }

            if (diamondsOwed > 0 || netheriteOwed > 0) {
                killer.sendMessage(Text.literal("You claimed " + diamondsOwed + " diamond(s) and "
                        + netheriteOwed + " netherite ingot(s) from " + victim.getName().getString() + "!")
                        .formatted(Formatting.GOLD));
            }
            DIAMOND_BOUNTY.remove(victimId);
            NETHERITE_BOUNTY.remove(victimId);

            // Every player kill increases the killer's bounty by one diamond.
            int kills = KILLS.merge(killerId, 1, Integer::sum);
            if (kills < 10) {
                // Kills 1 through 9: add eight diamonds for each kill.
                DIAMOND_BOUNTY.merge(killerId, 8, Integer::sum);
            } else {
                // From kill 10 onward, each new kill adds one full netherite ingot.
                NETHERITE_BOUNTY.merge(killerId, 1, Integer::sum);
            }

            int diamondBounty = DIAMOND_BOUNTY.getOrDefault(killerId, 0);
            int netheriteBounty = NETHERITE_BOUNTY.getOrDefault(killerId, 0);
            killer.sendMessage(Text.literal("Bounty increased! Your bounty: "
                    + diamondBounty + " diamond(s), " + netheriteBounty
                    + " netherite ingot(s). Total kills: " + kills)
                    .formatted(Formatting.AQUA));

            // Broadcast a simple server announcement.
            if (killer.getServer() != null) {
                killer.getServer().getPlayerManager().broadcast(
                        Text.literal(killer.getName().getString() + " now has a bounty of "
                                + diamondBounty + " diamond(s) + " + netheriteBounty + " netherite ingot(s)!")
                                .formatted(Formatting.RED), false);
            }
        });
    }
}
